function addNumbers(form){
    var x = form.n1.value;
    var y = form.n2.value;
    callScript(x, y, "add");
}

function subNumbers(form){
    var x = form.n1.value;
    var y = form.n2.value;
    callScript(x, y, "sub");
}

function callScript(x, y, operation){
		$.ajax({
		type: 'GET',			
		url: "http://127.0.0.1:8800/"+operation+"/"+x+"-"+y,
		contentType: 'text/plain',
		xhrFields: {
	    // The 'xhrFields' property sets additional fields on the XMLHttpRequest.
	    // This can be used to set the 'withCredentials' property.
	    // Set the value to 'true' if you'd like to pass cookies to the server.
	    // If this is enabled, your server must respond with the header
	    // 'Access-Control-Allow-Credentials: true'.`
	    withCredentials: false
	  	},
		success: function(response, textstat){
				response = "The " + operation + " of the numbers is :" + response;
				$('.result_'+operation).html(response);	
			}
	});
}

