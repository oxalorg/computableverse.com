from flask import Flask, make_response
app = Flask(__name__)

@app.route("/<int:x>-<int:y>")
def sum(x,y):
	resp = make_response(str(x+y))
	resp.headers['Access-Control-Allow-Origin'] = '*'
	return resp

if __name__ == '__main__':
	app.debug = True
	app.run(host="127.0.0.1", port=8800)