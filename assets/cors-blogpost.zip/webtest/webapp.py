from flask import Flask, make_response
app = Flask(__name__)

@app.route("/add/<x>/<y>")
def add(x, y):
	x = float(x)
	y = float(y)
	resp = make_response(str(x + y))
	resp.headers['Access-Control-Allow-Origin'] = '*'
	return resp

@app.route("/sub/<x>/<y>")
def sub(x, y):
	x = float(x)
	y = float(y)
	resp = make_response(str(x - y))
	resp.headers['Access-Control-Allow-Origin'] = '*'
	return resp

if __name__ == '__main__':
	app.debug = True
	app.run(host="127.0.0.1", port=8800)